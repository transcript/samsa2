touch configure.ac aclocal.m4 configure Makefile.am Makefile.in &&
./configure $@ &&
make